package com.example.demo.user.controller;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/user/role")
public class RoleController {

}
